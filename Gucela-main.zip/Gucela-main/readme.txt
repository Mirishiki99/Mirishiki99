Instructions:
1. import the database: ciblog.sql
2. Copy the files into your desired server, ex: XAMPP.
3. Run it by navigating to the root folder of the web-app in a browser EX: localhost/ci3_cubz.
